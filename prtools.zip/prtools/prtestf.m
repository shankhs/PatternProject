%PRTESTF Test feature selection
%
% A feature selection method stored as an untrained mapping w is tested

a = azizah;
