%PRFORUM
%
%	 N = PRFORUM(L)
%
%PRTools test

function prforum(k)

prforum_private(dataset,k);