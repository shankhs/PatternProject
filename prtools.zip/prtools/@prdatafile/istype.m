%ISTYPE Check datafile type
%
%   I = ISTYPE(A,TYPE)
