%MEDIAN Datafile overload
