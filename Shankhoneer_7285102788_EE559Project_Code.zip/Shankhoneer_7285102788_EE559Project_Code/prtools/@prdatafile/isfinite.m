%ISFINITE Datafile overload
