%TIMES Datafile overload
