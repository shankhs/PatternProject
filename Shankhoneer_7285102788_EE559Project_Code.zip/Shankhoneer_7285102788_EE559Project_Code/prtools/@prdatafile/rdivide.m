%RDIVIDE Datafile overload
