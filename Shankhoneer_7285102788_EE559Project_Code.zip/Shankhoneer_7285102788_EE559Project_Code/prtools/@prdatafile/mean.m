%MEAN Datafile overload
