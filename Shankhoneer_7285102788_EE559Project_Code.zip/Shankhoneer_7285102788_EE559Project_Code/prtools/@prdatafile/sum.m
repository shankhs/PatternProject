%SUM Datafile overload
