%SQRT Datafile overload
