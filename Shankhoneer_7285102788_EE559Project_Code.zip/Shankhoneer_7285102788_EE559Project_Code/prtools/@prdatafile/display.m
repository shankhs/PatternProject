%DISPLAY Display datafile information
