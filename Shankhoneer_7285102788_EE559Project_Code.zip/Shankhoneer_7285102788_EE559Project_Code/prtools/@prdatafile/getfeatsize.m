%GETFEATSIZE Get feature size of datafile
%
%	   FEATSIZE = GETFEATSIZE(A,N)
%    [FEATSIZE1,FEATSIZE2,FEATSIZE3] = GETFEATSIZE(A)
%
% Note that the feature size can be a scalar, or, in case of
% object images, an image size vector.
