%EQ Datafile overload
