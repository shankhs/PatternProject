%ISNAN Datafile overload
