%LDIVIDE Datafile overload
