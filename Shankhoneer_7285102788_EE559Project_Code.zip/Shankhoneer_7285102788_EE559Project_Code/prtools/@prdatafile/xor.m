%XOR Datafile overload
