%GT Datafile overload
