%LT Datafile overload
