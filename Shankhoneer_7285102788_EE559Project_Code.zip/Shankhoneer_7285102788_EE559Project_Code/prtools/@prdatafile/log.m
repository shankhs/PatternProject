%LOG Datafile overload
