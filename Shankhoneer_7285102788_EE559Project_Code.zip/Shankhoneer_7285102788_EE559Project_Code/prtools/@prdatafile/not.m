%NOT Logical NOT. Datafile overload
