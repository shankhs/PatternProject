%MTIMES Datafile overload
