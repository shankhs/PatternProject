%MEDIAN Datafile overload
