%ABS Datafile overload
