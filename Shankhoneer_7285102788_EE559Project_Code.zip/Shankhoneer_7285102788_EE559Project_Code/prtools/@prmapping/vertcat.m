%VERTCAT Mapping overload 
%
%  Vertical concatenation of mappings is performed by PARALLEL
