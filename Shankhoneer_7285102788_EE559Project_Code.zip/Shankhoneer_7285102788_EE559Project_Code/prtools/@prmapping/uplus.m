%UPLUS Fast extraction of the mapping data
%
%	  D = +W
%
% Converts a mapping object W to an object D, which is the
% contents of the mapping data field.
