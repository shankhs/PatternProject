%GETMAPPING_FILE Get mapping_file field in mapping
%
%    MAPPING_FILE = GETMAPPING_FILE(W)
%
% MAPPING_FILE is the file that will execute the mapping in a call
% as A*W or PRMAP(A,W).
