%Size Mapping overload
%
% The size of a mapping is [input_dimensionality,output_dimensionality]
