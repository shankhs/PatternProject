%PLUS. Mapping overload
