%SUBSASGN Subscript assignment overload for mappings
%
% This routine enables constructs like W.DATA = {DATA1, DATA2},
% i.e. the direct change of mapping fields.
