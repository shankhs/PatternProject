%GETSIZE_OUT Get size_out field of mapping
%
%    SIZE_OUT = GETSIZE_OUT(W)
