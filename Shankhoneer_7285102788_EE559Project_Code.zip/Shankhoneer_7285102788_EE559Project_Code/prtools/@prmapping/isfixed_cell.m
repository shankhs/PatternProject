%ISFIXED_CELL Test on fixed_cell mapping
%
%    I = ISFIXED_CELL(W)
%    ISFIXED_CELL(W)
%
% True if the mapping type of W is 'fixed_cell' (see HELP MAPPINGS).  
% If called without an output argument ISFIXED_CELL generates an error if 
% the mapping type of W is not 'fixed_cell'.
