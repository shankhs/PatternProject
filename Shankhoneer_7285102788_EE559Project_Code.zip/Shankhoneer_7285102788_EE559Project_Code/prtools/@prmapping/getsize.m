%GETSIZE Return size of a mapping
%
%   SIZE = GETSIZE(W)
%
% This function is identical to SIZE(W).
