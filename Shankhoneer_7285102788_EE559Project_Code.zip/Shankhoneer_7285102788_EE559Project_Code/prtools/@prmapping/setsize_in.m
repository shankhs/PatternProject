%SETSIZE_IN Set size_in field (input dimensionality) in mapping
%
%    W = SETSIZE_IN(W,SIZE_IN)
