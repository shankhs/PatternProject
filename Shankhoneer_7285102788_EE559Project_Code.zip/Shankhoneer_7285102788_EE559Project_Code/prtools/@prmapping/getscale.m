%GETSCALE Get scale field of mapping
%
%    SCALE = GETSCALE(W)
