%PRDATASET Conversion of affine mapping to dataset
%
%	A = PRDATASET(W)
%
% If W is a m x k affine mapping, the axes of the map
% are returned as a m x k dataset A.
