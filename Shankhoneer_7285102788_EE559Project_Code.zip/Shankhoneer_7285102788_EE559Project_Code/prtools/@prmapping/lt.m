%LT Mapping overload
