%GETOUT_CONV Get out_conv field in mapping
%
%    OUT_CONV = GETOUT_CONV(W)
