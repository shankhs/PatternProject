%NOT Mapping overload
