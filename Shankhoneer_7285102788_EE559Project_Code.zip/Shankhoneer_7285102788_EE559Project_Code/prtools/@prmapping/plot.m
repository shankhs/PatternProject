%PLOT Mapping overload (generates error)
