%SETSCALE Set scale field (output scaling) in mapping
%
%    W = SETSCALE(W,SCALE)
%
% This sets the SCALE field in W. If W is affine, scaling is is directly
% performed in the weights in W.DATA and W.SCALE = 1.
