%DOUBLE Mapping / double conversion
%
%	D = DOUBLE(W)
%
% Obsolete: conversion is not possible anymore, use +W to extract data.
