%DISPLAY Display mapping information
