%SUM Dataset overload
