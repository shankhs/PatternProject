%XOR Dataset overload
