%DISP Display dataset
%
%	DISP(A)
%
% Display dataset A and its content
