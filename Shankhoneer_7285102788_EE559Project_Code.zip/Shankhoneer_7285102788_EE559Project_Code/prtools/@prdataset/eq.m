%EQ Dataset overload
