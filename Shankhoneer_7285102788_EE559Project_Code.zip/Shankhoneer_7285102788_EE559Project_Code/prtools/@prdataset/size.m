%SIZE Size of dataset. Dataset overload
%
%	[M,K] = SIZE(A)
%
% M: number of objects
% K: number of features
