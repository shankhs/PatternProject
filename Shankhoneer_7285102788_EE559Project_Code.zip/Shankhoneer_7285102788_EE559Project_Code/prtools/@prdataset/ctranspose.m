%CTRANSPOSE Dataset overload 
%
% Returns the complex conjugate transpose of the data matrix.
% Construct a new dataset using the original featule labels as object
% labels and the other way around.
