%HORZCAT Dataset overload: horizontal concatenation, extended for features
