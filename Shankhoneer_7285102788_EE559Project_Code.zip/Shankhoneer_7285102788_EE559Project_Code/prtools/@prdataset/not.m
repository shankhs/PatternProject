%NOT Logical NOT. Dataset overload
