%CUMSUM Dataset overload
