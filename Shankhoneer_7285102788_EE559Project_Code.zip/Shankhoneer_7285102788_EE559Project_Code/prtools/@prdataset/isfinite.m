%ISFINITE Dataset overload
