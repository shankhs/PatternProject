%ISNAN Dataset overload
