%INVSIG The inverse sigmoid of a dataset
