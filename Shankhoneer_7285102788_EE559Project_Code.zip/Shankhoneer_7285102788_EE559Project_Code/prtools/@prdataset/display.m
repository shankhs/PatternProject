%DISPLAY Display dataset information
