clear;
clc;
PARTITION=5;
REPEAT=5;
MAX_DIM=54;

initData = LoadData('training_set/train_x.txt');
classLabels = LoadClassLabels('training_set/train_y.txt');
initData = initData';
initTestIntData = LoadData('testing_set_int_labeled/test_x_int_L.txt');
initTestIntLabel = LoadClassLabels('testing_set_int_labeled/test_y_int_L.txt');
initTestIntData = initTestIntData';

bestCs=[];
bestGammas=[];
for dim=1:1
    data = initData;
    data = data*klm(data,dim);
    A = prdataset(initData,classLabels);
    if dim>1
        A = A*normm;
    end
    data = A.data;
    nFolds = 5;
    [c gamma] = meshgrid(-5:2:15, -15:2:5);
    perfMat = zeros(numel(c),1);
    for i=1:numel(c)
        fprintf('Running svm for c = %f and gamma = %f\n',2^c(i),2^gamma(i));
        perfMat(i)=svmtrain(data,classLabels,sprintf('-q -t 0 -v %f -c %f -g %f',nFolds,2^c(i),2^gamma(i)));
    end
    [maxVal,idx] = max(perfMat)
    bestCs=[bestCs;2^c(idx)];
    bestGammas=[bestGammas;2^gamma(idx)];
end
